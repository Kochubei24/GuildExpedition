package com.guild.expedition

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_OVERLAY = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        findViewById<Button>(R.id.btnLaunch).setOnClickListener {
            if (!hasOverlayPermission()) {
                tvStatus.text = "Переходим в настройки разрешений..."
                requestOverlayPermission()
            } else {
                launchService()
                tvStatus.text = "✅ Виджет активен! Можно свернуть приложение."
            }
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, FloatingWidgetService::class.java))
            tvStatus.text = "⏹ Виджет остановлен."
        }
    }

    override fun onResume() {
        super.onResume()
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        tvStatus.text = if (hasOverlayPermission())
            "✅ Разрешение получено. Нажмите «Запустить»."
        else
            "⚠️ Нужно разрешение «Поверх других приложений»."
    }

    private fun hasOverlayPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(this)
        else true

    private fun requestOverlayPermission() {
        startActivityForResult(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
            REQ_OVERLAY
        )
    }

    private fun launchService() {
        val intent = Intent(this, FloatingWidgetService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(intent)
        else
            startService(intent)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY) {
            if (hasOverlayPermission()) {
                launchService()
                Toast.makeText(this, "Виджет запущен!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Разрешение не выдано", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
