package com.guild.expedition

import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.InputType
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.Locale

class FloatingWidgetService : Service() {

    companion object {
        private const val CHANNEL_ID = "guild_widget"
        private const val NOTIF_ID  = 1
        private val ROUTES = arrayOf("Left", "Mid", "Right")
        private const val PREFS = "guild_expedition_data"
    }

    private lateinit var wm: WindowManager
    private lateinit var bubble: View
    private lateinit var panel: View
    private var panelVisible = false
    private var currentPage = 1

    private val data = Array(3) { Array(8) { Array(4) { "" } } }
    private val holders = ArrayList<RowHolder>(8)

    data class RowHolder(val name: EditText, val n1: EditText, val n2: EditText, val n3: EditText)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadData()
        buildBubble()
        buildPanel()
    }

    override fun onDestroy() {
        if (::bubble.isInitialized) wm.removeView(bubble)
        if (::panel.isInitialized)  wm.removeView(panel)
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") stopSelf()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Guild Expedition", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingWidgetService::class.java).apply { action = "STOP" },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Guild Expedition")
            .setContentText("Виджет активен")
            .setSmallIcon(android.R.drawable.star_on)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stopIntent)
            .build()
    }

    private fun buildBubble() {
        val lp = overlayParams(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16; y = 300
        }
        bubble = LayoutInflater.from(this).inflate(R.layout.floating_widget, null)
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = ev.rawX; ty = ev.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - tx).toInt(); val dy = (ev.rawY - ty).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    lp.x = ix + dx; lp.y = iy + dy; wm.updateViewLayout(bubble, lp); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
        wm.addView(bubble, lp)
    }

    private fun buildPanel() {
        val lp = overlayParams(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        panel = LayoutInflater.from(this).inflate(R.layout.floating_window, null)
        panel.visibility = View.GONE

        panel.findViewById<View>(R.id.btnClose).setOnClickListener { saveCurrentPage(); hidePanel() }

        panel.findViewById<View>(R.id.btnNavLeft).setOnClickListener {
            saveCurrentPage(); currentPage = (currentPage - 1 + 3) % 3; refreshPage()
        }
        panel.findViewById<View>(R.id.btnNavRight).setOnClickListener {
            saveCurrentPage(); currentPage = (currentPage + 1) % 3; refreshPage()
        }

        panel.findViewById<View>(R.id.btnSave).setOnClickListener {
            saveCurrentPage()
            Toast.makeText(this, "Сохранено ✓", Toast.LENGTH_SHORT).show()
        }

        panel.findViewById<View>(R.id.btnList).setOnClickListener {
            saveCurrentPage(); showList()
        }

        panel.findViewById<View>(R.id.btnReset).setOnClickListener {
            panel.findViewById<View>(R.id.resetDialog).visibility = View.VISIBLE
        }

        // Сброс ников — только текущий маршрут
        panel.findViewById<View>(R.id.btnResetNicks).setOnClickListener {
            saveCurrentPage()
            for (i in 0 until 8) data[currentPage][i][0] = ""
            persistData(); refreshPage()
            panel.findViewById<View>(R.id.resetDialog).visibility = View.GONE
            Toast.makeText(this, "Ники сброшены (${ROUTES[currentPage]})", Toast.LENGTH_SHORT).show()
        }

        // Сброс всех ников — все маршруты
        panel.findViewById<View>(R.id.btnResetAllNicks).setOnClickListener {
            saveCurrentPage()
            for (r in 0..2) for (i in 0 until 8) data[r][i][0] = ""
            persistData(); refreshPage()
            panel.findViewById<View>(R.id.resetDialog).visibility = View.GONE
            Toast.makeText(this, "Все ники сброшены", Toast.LENGTH_SHORT).show()
        }

        // Сброс чисел — все маршруты
        panel.findViewById<View>(R.id.btnResetNumbers).setOnClickListener {
            saveCurrentPage()
            for (r in 0..2) for (i in 0 until 8) for (f in 1..3) data[r][i][f] = ""
            persistData(); refreshPage()
            panel.findViewById<View>(R.id.resetDialog).visibility = View.GONE
            Toast.makeText(this, "Все числа сброшены", Toast.LENGTH_SHORT).show()
        }

        panel.findViewById<View>(R.id.btnResetCancel).setOnClickListener {
            panel.findViewById<View>(R.id.resetDialog).visibility = View.GONE
        }

        panel.findViewById<View>(R.id.btnCopyList).setOnClickListener {
            val text = panel.findViewById<TextView>(R.id.tvListContent).text.toString()
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("guild_list", text))
            Toast.makeText(this, "Скопировано ✓", Toast.LENGTH_SHORT).show()
        }
        panel.findViewById<View>(R.id.btnListBack).setOnClickListener {
            panel.findViewById<View>(R.id.listOverlay).visibility = View.GONE
        }

        buildPlayerRows()
        refreshPage()
        wm.addView(panel, lp)
    }

    private fun buildPlayerRows() {
        val container = panel.findViewById<LinearLayout>(R.id.playersContainer)
        container.removeAllViews()
        holders.clear()

        for (i in 0 until 8) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(5), dp(6), dp(5))
                background = roundRect(0xFF1E1E2E.toInt(), dp(6).toFloat())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, dp(4)) }
            }

            val row1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val numLabel = TextView(this).apply {
                text = "${i + 1}"
                setTextColor(0xFF6677DD.toInt())
                textSize = 11f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                minWidth = dp(20)
                gravity = Gravity.CENTER
            }
            val nameEdit = makeEditText("Никнейм", false).apply {
                layoutParams = LinearLayout.LayoutParams(0, dp(30), 1f)
            }
            row1.addView(numLabel); row1.addView(nameEdit)

            val row2 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(20), dp(3), 0, 0)
            }
            val numLp = LinearLayout.LayoutParams(0, dp(28), 1f).apply { marginEnd = dp(3) }
            val n1 = makeEditText("0.00", true).apply { layoutParams = numLp }
            val n2 = makeEditText("0.00", true).apply { layoutParams = numLp }
            val n3 = makeEditText("0.00", true).apply { layoutParams = numLp }

            fun plus() = TextView(this).apply {
                text = "+"
                setTextColor(0xFF555566.toInt())
                textSize = 11f
                setPadding(dp(1), 0, dp(1), 0)
                gravity = Gravity.CENTER_VERTICAL
            }
            row2.addView(n1); row2.addView(plus())
            row2.addView(n2); row2.addView(plus())
            row2.addView(n3)

            card.addView(row1); card.addView(row2)
            container.addView(card)
            holders.add(RowHolder(nameEdit, n1, n2, n3))
        }
    }

    private fun makeEditText(hint: String, isNumber: Boolean): EditText {
        return EditText(this).apply {
            this.hint = hint
            setHintTextColor(0xFF444455.toInt())
            setTextColor(0xFFDDDDEE.toInt())
            textSize = 12f
            setPadding(dp(6), dp(2), dp(6), dp(2))
            background = roundRect(0xFF2A2A3E.toInt(), dp(4).toFloat())
            inputType = if (isNumber)
                InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_NEXT
            setSingleLine(true); maxLines = 1
        }
    }

    private fun refreshPage() {
        panel.findViewById<TextView>(R.id.tvRouteName).text = ROUTES[currentPage]
        for (i in 0 until 8) {
            holders[i].name.setText(data[currentPage][i][0])
            holders[i].n1.setText(data[currentPage][i][1])
            holders[i].n2.setText(data[currentPage][i][2])
            holders[i].n3.setText(data[currentPage][i][3])
        }
    }

    private fun saveCurrentPage() {
        for (i in 0 until 8) {
            data[currentPage][i][0] = holders[i].name.text.toString()
            data[currentPage][i][1] = holders[i].n1.text.toString()
            data[currentPage][i][2] = holders[i].n2.text.toString()
            data[currentPage][i][3] = holders[i].n3.text.toString()
        }
        persistData()
    }

    private fun showList() {
        data class PS(val name: String, val sum: Double)
        val players = ArrayList<PS>()
        for (i in 0 until 8) {
            val name = data[currentPage][i][0].trim()
            if (name.isBlank()) continue
            // Заменяем запятую на точку на случай локали
            val n1 = data[currentPage][i][1].replace(',', '.').toDoubleOrNull() ?: 0.0
            val n2 = data[currentPage][i][2].replace(',', '.').toDoubleOrNull() ?: 0.0
            val n3 = data[currentPage][i][3].replace(',', '.').toDoubleOrNull() ?: 0.0
            players.add(PS(name, n1 + n2 + n3))
        }
        players.sortByDescending { it.sum }

        val sb = StringBuilder()
        players.forEachIndexed { idx, p ->
            // Locale.US гарантирует точку как разделитель
            sb.append("${idx + 1}. ${p.name}: ${String.format(Locale.US, "%.2f", p.sum)}\n")
        }
        if (players.isEmpty()) sb.append("Нет данных для списка")

        panel.findViewById<TextView>(R.id.tvListTitle).text = "Список — ${ROUTES[currentPage]}"
        panel.findViewById<TextView>(R.id.tvListContent).text = sb.toString()
        panel.findViewById<View>(R.id.listOverlay).visibility = View.VISIBLE
    }

    private fun togglePanel() { if (panelVisible) hidePanel() else showPanel() }
    private fun showPanel()   { refreshPage(); panel.visibility = View.VISIBLE; panelVisible = true }
    private fun hidePanel()   { panel.visibility = View.GONE; panelVisible = false }

    private fun persistData() {
        val sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        for (r in 0..2) for (p in 0..7) for (f in 0..3) sp.putString("$r,$p,$f", data[r][p][f])
        sp.apply()
    }

    private fun loadData() {
        val sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for (r in 0..2) for (p in 0..7) for (f in 0..3) data[r][p][f] = sp.getString("$r,$p,$f", "") ?: ""
    }

    private fun overlayParams(flags: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        flags, PixelFormat.TRANSLUCENT
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun roundRect(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }
}
