package com.guild.expedition

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.InputType
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingWidgetService : Service() {

    // ─── Constants ────────────────────────────────────────────────
    companion object {
        private const val CHANNEL_ID = "guild_widget"
        private const val NOTIF_ID  = 1
        private val ROUTES = arrayOf("Left", "Mid", "Right")
        private val NAV_HINTS = arrayOf("Mid →", "← Left   Right →", "← Mid")
        private const val PREFS = "guild_expedition_data"
    }

    // ─── Views ────────────────────────────────────────────────────
    private lateinit var wm: WindowManager
    private lateinit var bubble: View
    private lateinit var panel: View
    private var panelVisible = false

    // ─── State ────────────────────────────────────────────────────
    private var currentPage = 1  // 0=Left, 1=Mid, 2=Right (start at Mid)

    // data[route][player][field]:  0=name, 1=num1, 2=num2, 3=num3
    private val data = Array(3) { Array(8) { Array(4) { "" } } }

    // EditText references for currently visible page
    private val holders = ArrayList<RowHolder>(8)

    data class RowHolder(val name: EditText, val n1: EditText, val n2: EditText, val n3: EditText)

    // ─── Lifecycle ────────────────────────────────────────────────
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadData()
        buildBubble()
        buildPanel()
    }

    override fun onDestroy() {
        if (::bubble.isInitialized) wm.removeView(bubble)
        if (::panel.isInitialized)  wm.removeView(panel)
        super.onDestroy()
    }

    // ─── Notification ─────────────────────────────────────────────
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Guild Expedition", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Виджет трекера экспедиции"
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingWidgetService::class.java).apply { action = "STOP" },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Guild Expedition")
            .setContentText("Виджет активен — нажмите ⚔ на экране")
            .setSmallIcon(android.R.drawable.star_on)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stopIntent)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") stopSelf()
        return START_STICKY
    }

    // ─── Bubble (floating button) ─────────────────────────────────
    private fun buildBubble() {
        val lp = overlayParams(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 300
        }

        bubble = LayoutInflater.from(this).inflate(R.layout.floating_widget, null)

        var initX = 0; var initY = 0
        var touchX = 0f; var touchY = 0f
        var wasMoved = false

        bubble.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = lp.x; initY = lp.y
                    touchX = ev.rawX; touchY = ev.rawY
                    wasMoved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - touchX).toInt()
                    val dy = (ev.rawY - touchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) wasMoved = true
                    lp.x = initX + dx; lp.y = initY + dy
                    wm.updateViewLayout(bubble, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!wasMoved) togglePanel()
                    true
                }
                else -> false
            }
        }

        wm.addView(bubble, lp)
    }

    // ─── Panel (main window) ──────────────────────────────────────
    private fun buildPanel() {
        val lp = overlayParams(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        panel = LayoutInflater.from(this).inflate(R.layout.floating_window, null)
        panel.visibility = View.GONE

        panel.findViewById<View>(R.id.btnClose).setOnClickListener {
            saveCurrentPage(); hidePanel()
        }
        panel.findViewById<View>(R.id.btnNavLeft).setOnClickListener {
            saveCurrentPage()
            currentPage = (currentPage - 1 + 3) % 3
            refreshPage()
        }
        panel.findViewById<View>(R.id.btnNavRight).setOnClickListener {
            saveCurrentPage()
            currentPage = (currentPage + 1) % 3
            refreshPage()
        }
        panel.findViewById<View>(R.id.btnSave).setOnClickListener {
            saveCurrentPage()
            Toast.makeText(this, "Сохранено ✓", Toast.LENGTH_SHORT).show()
        }

        buildPlayerRows()
        refreshPage()

        wm.addView(panel, lp)
    }

    // ─── Build 8 player rows programmatically ─────────────────────
    private fun buildPlayerRows() {
        val container = panel.findViewById<LinearLayout>(R.id.playersContainer)
        container.removeAllViews()
        holders.clear()

        for (i in 0 until 8) {
            // Outer card-like container
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(5), dp(6), dp(5))
                background = roundRect(0xFF1E1E2E.toInt(), dp(6).toFloat())
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, dp(4)) }
                layoutParams = lp
            }

            // — Row 1: index label + nickname field ——————————————
            val row1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val indexLabel = TextView(this).apply {
                text = "${i + 1}"
                setTextColor(0xFF6677DD.toInt())
                textSize = 11f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                minWidth = dp(20)
                gravity = Gravity.CENTER
            }

            val nameEdit = makeEditText("Никнейм", false).apply {
                layoutParams = LinearLayout.LayoutParams(0, dp(30), 1f)
            }

            row1.addView(indexLabel)
            row1.addView(nameEdit)

            // — Row 2: three number fields ————————————————————————
            val row2 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(20), dp(3), 0, 0)
            }

            val numLp = LinearLayout.LayoutParams(0, dp(28), 1f).apply {
                marginEnd = dp(3)
            }

            val n1 = makeEditText("0.00", true).apply { layoutParams = numLp }
            val n2 = makeEditText("0.00", true).apply { layoutParams = numLp }
            val n3 = makeEditText("0.00", true).apply { layoutParams = numLp }

            // "+" labels between numbers
            fun plusLabel() = TextView(this).apply {
                text = "+"
                setTextColor(0xFF555566.toInt())
                textSize = 11f
                setPadding(dp(1), 0, dp(1), 0)
                gravity = Gravity.CENTER_VERTICAL
            }

            row2.addView(n1)
            row2.addView(plusLabel())
            row2.addView(n2)
            row2.addView(plusLabel())
            row2.addView(n3)

            card.addView(row1)
            card.addView(row2)
            container.addView(card)
            holders.add(RowHolder(nameEdit, n1, n2, n3))
        }
    }

    private fun makeEditText(hint: String, isNumber: Boolean): EditText {
        return EditText(this).apply {
            this.hint = hint
            setHintTextColor(0xFF444455.toInt())
            setTextColor(0xFFDDDDEE.toInt())
            textSize = 12f
            setPadding(dp(6), dp(2), dp(6), dp(2))
            background = roundRect(0xFF2A2A3E.toInt(), dp(4).toFloat())
            inputType = if (isNumber)
                InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_NEXT
            setSingleLine(true)
            maxLines = 1
        }
    }

    // ─── Page refresh / save ──────────────────────────────────────
    private fun refreshPage() {
        panel.findViewById<TextView>(R.id.tvRouteName).text = ROUTES[currentPage]
        panel.findViewById<TextView>(R.id.tvNavHint).text   = NAV_HINTS[currentPage]

        for (i in 0 until 8) {
            holders[i].name.setText(data[currentPage][i][0])
            holders[i].n1.setText(data[currentPage][i][1])
            holders[i].n2.setText(data[currentPage][i][2])
            holders[i].n3.setText(data[currentPage][i][3])
        }
    }

    private fun saveCurrentPage() {
        for (i in 0 until 8) {
            data[currentPage][i][0] = holders[i].name.text.toString()
            data[currentPage][i][1] = holders[i].n1.text.toString()
            data[currentPage][i][2] = holders[i].n2.text.toString()
            data[currentPage][i][3] = holders[i].n3.text.toString()
        }
        persistData()
    }

    // ─── Visibility ───────────────────────────────────────────────
    private fun togglePanel() {
        if (panelVisible) hidePanel() else showPanel()
    }

    private fun showPanel() {
        refreshPage()
        panel.visibility = View.VISIBLE
        panelVisible = true
    }

    private fun hidePanel() {
        panel.visibility = View.GONE
        panelVisible = false
    }

    // ─── Storage ──────────────────────────────────────────────────
    private fun persistData() {
        val sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        for (r in 0..2) for (p in 0..7) for (f in 0..3) {
            sp.putString("$r,$p,$f", data[r][p][f])
        }
        sp.apply()
    }

    private fun loadData() {
        val sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for (r in 0..2) for (p in 0..7) for (f in 0..3) {
            data[r][p][f] = sp.getString("$r,$p,$f", "") ?: ""
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────
    private fun overlayParams(flags: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        flags,
        PixelFormat.TRANSLUCENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun roundRect(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }
}
